class PeriodAlreadyLoadedException(Exception):
    pass