class DataNotAvailableError(Exception):
    pass